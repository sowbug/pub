#ifndef _EXT_ANIM_H_
#define _EXT_ANIM_H_

// 	NOTE: This file is obsolete.

#endif /* _EXT_ANIM_H_ */
